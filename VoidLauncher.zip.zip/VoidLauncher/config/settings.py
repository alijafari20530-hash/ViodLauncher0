SAFE_PROCESSES = [
    "explorer.exe",
    "dwm.exe",
    "csrss.exe",
    "winlogon.exe",
    "services.exe"
]

BOOST_TARGETS = [
    "Discord.exe",
    "Spotify.exe",
    "Chrome.exe",
    "opera.exe",
    "msedge.exe"
]

GAME_EXECUTABLES = [
    "VALORANT-Win64-Shipping.exe",
    "FortniteClient-Win64-Shipping.exe",
    "LeagueClient.exe",
    "MinecraftLauncher.exe"
]