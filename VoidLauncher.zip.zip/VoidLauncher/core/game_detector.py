import psutil
from config.settings import GAME_EXECUTABLES

class GameDetector:

    def detect_running_game(self):
        for proc in psutil.process_iter(['name']):
            try:
                if proc.info['name'] in GAME_EXECUTABLES:
                    return proc.info['name']
            except:
                pass

        return None