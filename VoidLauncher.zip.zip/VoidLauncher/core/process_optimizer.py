import psutil
from config.settings import SAFE_PROCESSES, BOOST_TARGETS

class ProcessOptimizer:

    def optimize(self):
        closed = []

        for proc in psutil.process_iter(['pid', 'name']):
            try:
                name = proc.info['name']

                if name in SAFE_PROCESSES:
                    continue

                if name in BOOST_TARGETS:
                    proc.kill()
                    closed.append(name)

            except:
                pass

        return closed