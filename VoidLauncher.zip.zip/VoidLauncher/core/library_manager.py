from pathlib import Path

class LibraryManager:

    def steam_games(self):
        steam_path = Path("C:/Program Files (x86)/Steam/steamapps")

        games = []

        if steam_path.exists():
            for game in steam_path.glob("appmanifest_*.acf"):
                games.append(game.stem)

        return games

    def epic_games(self):
        epic_path = Path("C:/ProgramData/Epic/EpicGamesLauncher/Data/Manifests")

        games = []

        if epic_path.exists():
            for game in epic_path.glob("*.item"):
                games.append(game.stem)

        return games