# VoidLauncher

Advanced Gaming Launcher + FPS Booster

## Features
- Unified game library
- Steam detection
- Epic Games detection
- Smart process optimizer
- Gaming dashboard
- Performance monitor
- Auto game detection

## Install

pip install -r requirements.txt

## Run

python main.py