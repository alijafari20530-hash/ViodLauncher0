from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QListWidget
)

from core.library_manager import LibraryManager

class LibraryPage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("GAME LIBRARY")
        title.setStyleSheet("font-size: 30px; font-weight: bold;")

        self.games = QListWidget()

        layout.addWidget(title)
        layout.addWidget(self.games)

        self.setLayout(layout)

        self.load_games()

    def load_games(self):
        manager = LibraryManager()

        steam = manager.steam_games()
        epic = manager.epic_games()

        self.games.addItem("=== STEAM ===")

        for game in steam:
            self.games.addItem(game)

        self.games.addItem("")
        self.games.addItem("=== EPIC GAMES ===")

        for game in epic:
            self.games.addItem(game)