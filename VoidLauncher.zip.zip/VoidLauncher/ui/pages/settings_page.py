from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QCheckBox
)

class SettingsPage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("SETTINGS")
        title.setStyleSheet("font-size: 30px; font-weight: bold;")

        auto_boost = QCheckBox("Enable Auto Boost")
        startup = QCheckBox("Run on Startup")

        layout.addWidget(title)
        layout.addWidget(auto_boost)
        layout.addWidget(startup)

        self.setLayout(layout)