from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel
)

import psutil

class PerformancePage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent

        title = QLabel("PERFORMANCE MONITOR")
        title.setStyleSheet("font-size: 30px; font-weight: bold;")

        cpu_label = QLabel(f"CPU Usage: {cpu}%")
        ram_label = QLabel(f"RAM Usage: {ram}%")

        layout.addWidget(title)
        layout.addWidget(cpu_label)
        layout.addWidget(ram_label)

        self.setLayout(layout)