from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit
)

from core.process_optimizer import ProcessOptimizer
from core.game_detector import GameDetector

class DashboardPage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        self.title = QLabel("VOIDLAUNCHER")
        self.title.setStyleSheet("font-size: 40px; font-weight: bold;")

        self.status = QLabel("System Ready")

        self.boost_button = QPushButton("BOOST PERFORMANCE")
        self.boost_button.clicked.connect(self.boost)

        self.logs = QTextEdit()
        self.logs.setReadOnly(True)

        layout.addWidget(self.title)
        layout.addWidget(self.status)
        layout.addWidget(self.boost_button)
        layout.addWidget(self.logs)

        self.setLayout(layout)

        self.detector = GameDetector()

    def boost(self):
        optimizer = ProcessOptimizer()

        closed = optimizer.optimize()

        game = self.detector.detect_running_game()

        self.logs.append("=== BOOST STARTED ===")

        if game:
            self.logs.append(f"Detected Game: {game}")

        for app in closed:
            self.logs.append(f"Closed: {app}")

        self.logs.append("Optimization Complete")