from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QHBoxLayout,
    QListWidget,
    QStackedWidget
)

from ui.pages.dashboard_page import DashboardPage
from ui.pages.library_page import LibraryPage
from ui.pages.performance_page import PerformancePage
from ui.pages.settings_page import SettingsPage

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("VoidLauncher")
        self.resize(1400, 900)

        root = QWidget()
        self.setCentralWidget(root)

        layout = QHBoxLayout()

        self.sidebar = QListWidget()
        self.sidebar.setFixedWidth(220)

        self.sidebar.addItems([
            "Dashboard",
            "Library",
            "Performance",
            "Settings"
        ])

        self.pages = QStackedWidget()

        self.dashboard = DashboardPage()
        self.library = LibraryPage()
        self.performance = PerformancePage()
        self.settings = SettingsPage()

        self.pages.addWidget(self.dashboard)
        self.pages.addWidget(self.library)
        self.pages.addWidget(self.performance)
        self.pages.addWidget(self.settings)

        self.sidebar.currentRowChanged.connect(
            self.pages.setCurrentIndex
        )

        layout.addWidget(self.sidebar)
        layout.addWidget(self.pages)

        root.setLayout(layout)

        self.setStyleSheet('''
            QWidget {
                background-color: #111111;
                color: white;
                font-size: 15px;
            }

            QListWidget {
                background-color: #1a1a1a;
                border: none;
            }

            QPushButton {
                background-color: #2d2d2d;
                padding: 12px;
                border-radius: 10px;
            }

            QPushButton:hover {
                background-color: #404040;
            }
        ''')