from pathlib import Path

class Library:

    def steam_games(self):
        games = []
        steam = Path("C:/Program Files (x86)/Steam/steamapps")

        if steam.exists():
            for game in steam.glob("appmanifest_*.acf"):
                games.append(game.stem)

        return games