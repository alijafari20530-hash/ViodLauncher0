# VoidLauncher

Modern Gaming Launcher + FPS Optimizer built with Python and PyQt6.

## Features
- Unified Game Library
- Steam Detection
- Epic Games Detection
- FPS Boost Mode
- Safe Process Optimization
- Performance Monitor
- Modern Gaming UI
- GitHub Actions Auto Build

## Installation

```bash
pip install -r requirements.txt
python main.py
```

## Build EXE

```bash
pip install nuitka
python -m nuitka --standalone --enable-plugin=pyqt6 --windows-console-mode=disable main.py
```

## Tech Stack
- Python
- PyQt6
- psutil
- Nuitka