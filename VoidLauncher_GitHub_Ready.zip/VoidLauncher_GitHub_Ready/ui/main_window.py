from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QHBoxLayout,
    QListWidget,
    QStackedWidget
)

from ui.pages.dashboard import Dashboard
from ui.pages.library import LibraryPage
from ui.pages.performance import PerformancePage

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("VoidLauncher")
        self.resize(1500, 900)

        root = QWidget()
        self.setCentralWidget(root)

        layout = QHBoxLayout()

        self.sidebar = QListWidget()
        self.sidebar.setFixedWidth(220)

        self.sidebar.addItems([
            "Dashboard",
            "Library",
            "Performance"
        ])

        self.pages = QStackedWidget()

        self.dashboard = Dashboard()
        self.library = LibraryPage()
        self.performance = PerformancePage()

        self.pages.addWidget(self.dashboard)
        self.pages.addWidget(self.library)
        self.pages.addWidget(self.performance)

        self.sidebar.currentRowChanged.connect(
            self.pages.setCurrentIndex
        )

        layout.addWidget(self.sidebar)
        layout.addWidget(self.pages)

        root.setLayout(layout)

        self.setStyleSheet('''
            QWidget {
                background: #0f0f0f;
                color: white;
                font-size: 14px;
            }

            QListWidget {
                background: #161616;
                border: none;
                padding: 10px;
            }

            QPushButton {
                background: #272727;
                border-radius: 12px;
                padding: 14px;
            }

            QPushButton:hover {
                background: #3a3a3a;
            }
        ''')