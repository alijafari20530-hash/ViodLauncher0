from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel
)

import psutil

class PerformancePage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("PERFORMANCE")
        title.setStyleSheet("font-size: 30px; font-weight: bold;")

        cpu = QLabel(f"CPU Usage: {psutil.cpu_percent()}%")
        ram = QLabel(f"RAM Usage: {psutil.virtual_memory().percent}%")

        layout.addWidget(title)
        layout.addWidget(cpu)
        layout.addWidget(ram)

        self.setLayout(layout)