from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QListWidget
)

from core.library import Library

class LibraryPage(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("GAME LIBRARY")
        title.setStyleSheet("font-size: 30px; font-weight: bold;")

        self.games = QListWidget()

        layout.addWidget(title)
        layout.addWidget(self.games)

        self.setLayout(layout)

        self.load_games()

    def load_games(self):
        lib = Library()

        games = lib.steam_games()

        for game in games:
            self.games.addItem(game)