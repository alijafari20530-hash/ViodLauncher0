from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit
)

from core.optimizer import Optimizer

class Dashboard(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()

        title = QLabel("VOIDLAUNCHER")
        title.setStyleSheet("font-size: 40px; font-weight: bold;")

        subtitle = QLabel("Gaming Performance Optimizer")

        self.button = QPushButton("BOOST PERFORMANCE")
        self.button.clicked.connect(self.boost)

        self.logs = QTextEdit()
        self.logs.setReadOnly(True)

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addWidget(self.button)
        layout.addWidget(self.logs)

        self.setLayout(layout)

    def boost(self):
        optimizer = Optimizer()

        results = optimizer.optimize()

        self.logs.append("Optimization Started")

        for app in results:
            self.logs.append(f"Closed: {app}")

        self.logs.append("Boost Complete")