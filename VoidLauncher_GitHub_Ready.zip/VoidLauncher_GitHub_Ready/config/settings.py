SAFE_PROCESSES = [
    "explorer.exe",
    "dwm.exe",
    "csrss.exe",
    "winlogon.exe",
    "services.exe"
]

BOOST_TARGETS = [
    "Discord.exe",
    "Spotify.exe",
    "Chrome.exe",
    "opera.exe",
    "msedge.exe"
]